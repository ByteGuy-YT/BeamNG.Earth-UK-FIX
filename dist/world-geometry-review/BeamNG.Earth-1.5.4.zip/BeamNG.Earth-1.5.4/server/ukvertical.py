"""Separate upper road profiles from terrain at mapped UK grade separations.

The DEM is one surface, not two floors. Sampling its trench into an upper road and
then adding clearance created motorway humps. This model samples the approach
trend outside a short structure. Motorway/trunk mainlines keep their own grade;
secondary overbridges rise to clear them. Other lower roads may be excavated.
No site coordinates or surveyed-height claims. Long viaducts retain the legacy solver.
"""
import math
import threading
import numpy as np
import mapcells


def underpass_ranges(ll, tags):
    """An explicitly mapped subway crossing needs a deck in the upper road."""
    if tags.get('highway','').removesuffix('_link') not in ('motorway','trunk','primary','secondary','tertiary'):
        return []
    import ukcontext
    import roads
    pad=.0001
    records=ukcontext.features((ll[:,0].min()-pad,ll[:,1].min()-pad,ll[:,0].max()+pad,ll[:,1].max()+pad),('underpass',))
    scale=np.array([111320.*np.cos(np.radians(ll[:,1].mean())),111320.])
    xy=(ll-ll[0])*scale
    length=np.linalg.norm(np.diff(xy,axis=0),axis=1).sum()
    if length<1.:return []
    out=[]
    for _,_,t,geom in records:
        path=(geom-ll[0])*scale
        if len(path)<2:continue
        for _,at,q in roads._crossings([xy],[path]):
            # The full path corridor plus concrete abutments, clipped to this source section.
            half=5.
            out.append((max(0.,(at-half)/length),min(1.,(at+half)/length),'bridge'))
    merged=[]
    for a,b,k in sorted(out):
        if merged and a<=merged[-1][1]:merged[-1]=(merged[-1][0],max(b,merged[-1][1]),k)
        else:merged.append((a,b,k))
    return merged


def approach_profile(xy, sample):
    """Robust local grade across a short span, using both approaches, not its trench."""
    xy = np.asarray(xy, float)[:, :2]
    s = np.r_[0., np.cumsum(np.linalg.norm(np.diff(xy, axis=0), axis=1))]
    if s[-1] < 1.:
        return np.asarray(sample(xy), float)
    u, v = xy[1]-xy[0], xy[-1]-xy[-2]
    u /= max(np.linalg.norm(u), 1e-9); v /= max(np.linalg.norm(v), 1e-9)
    d = np.array([20., 40., 70.])
    q = np.r_[xy[0]-d[:, None]*u, xy[-1]+d[:, None]*v]
    z = np.asarray(sample(q), float)
    # Median pairwise grades tolerate a bad DEM sample on either verge/approach.
    st = np.r_[-d, s[-1]+d]
    slopes = [(z[j]-z[i])/(st[j]-st[i]) for i in range(6) for j in range(i+1,6) if abs(st[j]-st[i])>5]
    slope = float(np.clip(np.median(slopes), -.08, .08))
    intercept = float(np.median(z-slope*st))
    return intercept+slope*s


def project(q, xy):
    d = np.diff(xy[:, :2], axis=0); l2 = np.maximum((d*d).sum(1), 1e-12)
    t = np.clip(((q[:, None, :]-xy[None, :-1, :2])*d).sum(2)/l2, 0., 1.)
    delta = q[:, None, :]-xy[None, :-1, :2]-t[..., None]*d
    dist = np.linalg.norm(delta, axis=2); k = dist.argmin(1)
    s = np.r_[0., np.cumsum(np.sqrt(l2))]
    at = s[k]+t[np.arange(len(q)), k]*np.sqrt(l2[k])
    return dist[np.arange(len(q)), k], at, s


def approach_ownership(xy, plans, priority):
    """Upper approaches own their corridor, never a lower road beside/beneath it.

    Reapplying a truncated approach's lateral fill ramp over a motorway created
    a small bump at its far end. Compare centreline distances to the complete
    ground network before applying the priority pass, with a 1 m soft boundary.
    """
    def distances(rows, ids, initial):
        out=initial.copy()
        if not len(ids) or not rows:return out
        qlo=xy[ids].min(0);qhi=xy[ids].max(0)
        segments=[];reach=max(p.half for p in rows)+1.
        for p in rows:
            if p.bbox[2]<qlo[0] or p.bbox[0]>qhi[0] or p.bbox[3]<qlo[1] or p.bbox[1]>qhi[1]:continue
            a,b=p.xy[:-1],p.xy[1:]
            keep=(np.maximum(a,b)>=qlo-reach).all(1)&(np.minimum(a,b)<=qhi+reach).all(1)
            if keep.any():segments.append(np.c_[a[keep],b[keep]])
        if not segments:return out
        seg=np.concatenate(segments);a,b=seg[:,:2],seg[:,2:]
        low=np.minimum(a,b);high=np.maximum(a,b)
        buckets=np.floor(xy[ids]/32.).astype(np.int64)
        unique,inverse=np.unique(buckets,axis=0,return_inverse=True)
        for j,cell in enumerate(unique):
            k=ids[inverse==j];lo=cell*32.-reach;hi=(cell+1)*32.+reach
            keep=(high>=lo).all(1)&(low<=hi).all(1)
            if not keep.any():continue
            aa=a[keep];d=b[keep]-aa;l2=np.maximum((d*d).sum(1),1e-12)
            for start in range(0,len(k),256):
                kk=k[start:start+256];delta=xy[kk,None,:]-aa
                t=np.clip((delta*d).sum(2)/l2,0.,1.)
                out[kk]=np.linalg.norm(delta-t[...,None]*d,axis=2).min(1)
        return out
    ids=np.arange(len(xy));empty=np.full(len(xy),np.inf)
    dp=distances(priority,ids,empty)
    active=np.flatnonzero(np.isfinite(dp))
    dn=distances(plans,active,empty)
    weight=np.zeros(len(xy));weight[active]=np.clip(1.-(dp[active]-dn[active]),0.,1.)
    return weight


class Model:
    def __init__(self, frame, md, raw):
        self.frame, self.md, self.raw = frame, md, raw
        self.cache, self.lock = {}, threading.RLock()
        self.path_cache={}
        self.upper_plans={}
        self.levels={}
        self.near_cache={}
        self.network_cache={}
        self.network_graphs={}
        self.network_bounds={}
        self.cut_cache={}
        self.graph_cache={}
        self.mainline_plans={}
        self.mainline_profiles={}

    def sample(self, xy):
        la, lo, _ = self.frame.enu_to_geodetic(xy[:,0], xy[:,1], 0.)
        return np.asarray(self.raw(la, lo), float)

    def cell(self, key):
        import roads
        with self.lock:
            if key in self.cache:
                return self.cache[key]
            f = self.md.cell(key, layers=('roads',), kind='demand').layers.get('roads')
            out = []
            if f is not None:
                for i, sp in enumerate(roads.bridge_specs(f)):
                    if sp is None or sp.profile is None:
                        continue
                    try:level=float(__import__('roadprofile').tags_for(f,i).get('layer','1') or 1.)
                    except (TypeError,ValueError):level=1.
                    self.levels[str(f.ids[i])]=level
                    for ring in roads.bridge_parts(f, i):
                        la, lo = ring[:,1], ring[:,0]
                        x,y,_ = self.frame.geodetic_to_enu(la, lo, 0.)
                        from grading import resample
                        xy,_ = resample(np.c_[x,y], 4.)
                        xy=roads.RouteLine(xy,roads._route_end_ids(f,i,ring))
                        length = np.linalg.norm(np.diff(xy, axis=0), axis=1).sum()
                        if not 4. <= length <= 1000.:
                            continue
                        # Short road/rail/path crossings only; water viaducts keep their solver.
                        z = approach_profile(xy, self.sample)
                        if length>180.:
                            from grading import smooth_profile
                            natural=smooth_profile(self.sample(xy),4.,40.)
                            st=np.r_[0.,np.cumsum(np.linalg.norm(np.diff(xy,axis=0),axis=1))]
                            correction=np.interp(st,[0.,st[-1]],[z[0]-natural[0],z[-1]-natural[-1]])
                            z=natural+correction
                        # Surface roads below keep their independent grade. Raise
                        # the mapped upper bridge to provide clearance.
                        row=(xy,z,sp.width/2,str(f.ids[i]))
                        _,_,_,ground=self.network(row)
                        raise_by=0.
                        for gi in self.crossing_indices(xy,ground):
                            # Keep a mainline on its independently sampled
                            # approach trend. Its underpass road can be absent
                            # from the single-surface DEM below the embankment.
                            if sp.profile.mainline:continue
                            lower,lsp=ground[gi]
                            crossings=roads._crossings([xy],[lower])
                            if not crossings:continue
                            profile_key=(tuple(np.round(lower[0],3)),tuple(np.round(lower[-1],3)),lsp.width,lsp.profile.offset)
                            if profile_key not in self.mainline_profiles:
                                from grading import plan_road
                                la,lo,_=self.frame.enu_to_geodetic(lower[:,0],lower[:,1],0.)
                                self.mainline_profiles[profile_key]=plan_road(self.frame,np.c_[lo,la],lsp,self.raw)
                            plan=self.mainline_profiles[profile_key]
                            upper_s=np.r_[0.,np.cumsum(np.linalg.norm(np.diff(xy,axis=0),axis=1))]
                            for _,at,q in crossings:
                                if at<2. or at>upper_s[-1]-2.:continue
                                _,ls,ps=project(np.asarray(q)[None,:2],plan.xy)
                                lower_z=float(np.interp(ls[0],ps,plan.z))
                                need=lower_z+roads.DECK_ROAD_CLEAR
                                raise_by=max(raise_by,need-float(np.interp(at,upper_s,z)))
                        z=z+raise_by
                        out.append((xy, z, sp.width/2+abs(sp.profile.surface_offset), str(f.ids[i])))
            self.cache[key] = out
            return out

    def near(self, xy, margin=100.):
        la,lo,_ = self.frame.enu_to_geodetic(xy[:,0],xy[:,1],0.)
        pad=margin/111320.; pl=pad/max(.05,math.cos(math.radians(float(np.mean(la)))))
        keys=mapcells.cells_for_bbox(float(min(la))-pad,float(min(lo))-pl,float(max(la))+pad,float(max(lo))+pl)
        cache_key=tuple(sorted(map(str,keys)))
        lo_xy=xy[:,:2].min(0)-margin;hi_xy=xy[:,:2].max(0)+margin
        def local(rows):
            return [r for r in rows if (r[0].max(0)>=lo_xy).all() and (r[0].min(0)<=hi_xy).all()]
        if cache_key in self.near_cache:return local(self.near_cache[cache_key])
        out, seen = [], set()
        for key in sorted(keys,key=str):
            for row in self.cell(key):
                sig=(row[3],tuple(np.round(row[0][0],2)),tuple(np.round(row[0][-1],2)))
                if sig not in seen:
                    seen.add(sig);out.append(row)
        # Adjacent carriageways share a bridge's vertical alignment. DEM pixels
        # on opposite embankment edges are not independent deck surveys.
        targets=[r[1].copy() for r in out]
        for i,(line,z,half,fid) in enumerate(out):
            u=line[-1]-line[0];length=np.linalg.norm(u)
            if length<1.:continue
            u/=length
            for j in range(i):
                other,oz,oh,ofid=out[j]
                if self.levels.get(fid)!=self.levels.get(ofid):continue
                v=other[-1]-other[0];ol=np.linalg.norm(v)
                if ol<1. or not .65<length/ol<1.5 or abs(u@(v/ol))<.97:continue
                delta=line.mean(0)-other.mean(0)
                lateral=abs(delta[0]*u[1]-delta[1]*u[0])
                if not 1.<lateral<half+oh+8. or abs(delta@u)>min(20.,length*.3):continue
                _,at,s=project(line,other)
                targets[i]=np.maximum(targets[i],np.interp(at,s,oz))
                _,at,s=project(other,line)
                targets[j]=np.maximum(targets[j],np.interp(at,s,z))
        import roads
        targets=roads._limit_deck_grades([r[0] for r in out],roads._join_decks([r[0] for r in out],targets))
        out=[(r[0],z,r[2],r[3]) for r,z in zip(out,targets)]
        if len(self.near_cache)>128:self.near_cache.clear()
        self.near_cache[cache_key]=out
        return local(out)

    def deck(self, fid, xy):
        best=None
        for line,z,_,name in self.near(xy, 5.):
            if name == fid:
                dist,at,s=project(xy[:,:2],line)
                error=float(dist.max())
                if error<.75 and (best is None or error<best[0]):best=(error,np.interp(at,s,z))
        return best[1] if best else None

    def paths(self, xy):
        """Mapped pedestrian subways; floor and bore are independent of the upper road."""
        import ukcontext, roads
        la,lo,_=self.frame.enu_to_geodetic(xy[:,0],xy[:,1],0.)
        bounds=(float(min(lo))-.001,float(min(la))-.001,float(max(lo))+.001,float(max(la))+.001)
        out=[]
        for oid,_,t,ll in ukcontext.features(bounds,('underpass',)):
            if t.get('tunnel')=='building_passage' or len(ll)<2:continue
            if oid not in self.path_cache:
                x,y,_=self.frame.geodetic_to_enu(ll[:,1],ll[:,0],0.)
                line=roads.densify(np.c_[x,y],2.)
                floor=approach_profile(line,self.sample)
                for upper,top,half,_ in self.near(line,5.):
                    cr=roads._crossings([line],[upper])
                    if cr:
                        q=np.asarray(cr[0][2])[None,:2];_,station,s=project(q,upper)
                        ceiling=float(np.interp(station[0],s,top))
                        floor=np.minimum(floor,ceiling-5.4)
                self.path_cache[oid]=(line,floor,1.5)
            out.append(self.path_cache[oid])
        return out

    def network(self, structure):
        """One canonical ground network for both floors' connected approaches."""
        import roads
        line,z,half,fid=structure
        key=(fid,tuple(np.round(line[0],2)),tuple(np.round(line[-1],2)))
        if key in self.graph_cache:return self.graph_cache[key]
        la,lo,_=self.frame.enu_to_geodetic(line[:,0],line[:,1],0.)
        pad=450./111320.;pl=pad/max(.05,math.cos(math.radians(float(np.mean(la)))))
        keys=mapcells.cells_for_bbox(float(min(la))-pad,float(min(lo))-pl,float(max(la))+pad,float(max(lo))+pl)
        keys=tuple(sorted(keys,key=str))
        network_key=tuple(map(str,keys))
        if network_key in self.network_graphs:
            result=self.network_graphs[network_key]
            self.graph_cache[key]=result
            return result
        lines=[];seen=set()
        for ck in keys:
            if ck not in self.network_cache:
                f=self.md.cell(ck,layers=('roads',),kind='demand').layers.get('roads');rows=[]
                if f is not None:
                    for i,sp in enumerate(roads.road_specs(f)):
                        if sp is None or sp.profile is None:continue
                        for ll in roads.ground_parts(f,i):
                            x,y,_=self.frame.geodetic_to_enu(ll[:,1],ll[:,0],0.)
                            rows.append((np.c_[x,y],sp))
                self.network_cache[ck]=rows
            for xy,sp in self.network_cache[ck]:
                sig=tuple(np.round(np.r_[xy[0],xy[-1]],2))
                if sig not in seen:seen.add(sig);lines.append((xy,sp))
        nodes,edges,adj=roads._chain_graph([xy for xy,_ in lines]);nodes=np.asarray(nodes)
        result=(nodes,edges,adj,lines)
        self.network_graphs[network_key]=result
        self.graph_cache[key]=result
        return result

    def crossing_indices(self,line,ground):
        key=id(ground)
        if key not in self.network_bounds:
            self.network_bounds[key]=(np.array([g[0].min(0) for g in ground]).reshape(-1,2),
                                      np.array([g[0].max(0) for g in ground]).reshape(-1,2))
        lo,hi=self.network_bounds[key]
        return np.flatnonzero((hi>=line.min(0)).all(1)&(lo<=line.max(0)).all(1))

    def cuts(self, structure):
        """Lower clearance follows source seams; at most 5% added approach grade."""
        import roads
        line,z,half,fid=structure
        key=(fid,tuple(np.round(line[0],2)),tuple(np.round(line[-1],2)))
        if key in self.cut_cache:return self.cut_cache[key]
        nodes,edges,adj,lines=self.network(structure)
        cuts=[]
        for k in self.crossing_indices(line,lines):
            xy,sp=lines[k]
            if sp.profile.mainline:continue
            for _,upper_at,q in roads._crossings([line],[xy]):
                upper_s=np.r_[0.,np.cumsum(np.linalg.norm(np.diff(line,axis=0),axis=1))]
                if upper_at<2. or upper_at>upper_s[-1]-2.:continue
                _,lower_at,s=project(np.asarray(q)[None,:2],xy)
                a,b,ss=edges[k]
                distances=roads._dijkstra(adj,{a:float(lower_at[0]),b:float(s[-1]-lower_at[0])})
                clearance=5.4 if sp.cls in ('track','path','footway','cycleway') else roads.DECK_ROAD_CLEAR
                floor=float(np.interp(upper_at,upper_s,z))-clearance
                cuts.append((nodes,distances,floor,half,xy,float(lower_at[0])))
        self.cut_cache[key]=cuts
        return cuts

    def adjust(self, plans, specs):
        """Approaches join the upper profile; crossing ground routes stay below its soffit."""
        import roads
        if not plans:
            return
        structures=self.near(np.concatenate([p.xy for _,p in plans]),100.)
        lower_cuts=[cut for structure in structures for cut in self.cuts(structure)]
        upper_seeds=[]
        for structure in structures:
            line,z,half,name=structure
            nodes,edges,adj,lines=self.network(structure)
            if not len(nodes):continue
            for be in (0,-1):
                at=int(np.argmin(np.linalg.norm(nodes-line[be],axis=1)))
                if np.linalg.norm(nodes[at]-line[be])>.75:continue
                distances=roads._dijkstra(adj,{at:0.})
                correction=float(z[be]-self.sample(line[[be]])[0])
                radius=max(100.,abs(correction)*np.pi/(2*.045))
                upper_seeds.append((nodes,distances,line[be],z[be],correction,radius))
        for i, ((fid,p), sp) in enumerate(zip(plans,specs)):
            if sp.profile is None:
                continue
            topology=p.xy
            if sp.profile.surface_offset:
                topology=roads.offset_polyline(np.c_[p.xy,np.zeros(len(p.xy))],-sp.profile.surface_offset)[:,:2]
            s=np.r_[0.,np.cumsum(np.linalg.norm(np.diff(p.xy,axis=0),axis=1))]
            zz=p.z.copy()
            upper_active=np.zeros(len(p.xy),bool)
            for nodes,distances,seed,top,correction,radius in upper_seeds:
                ends=topology[[0,-1]]
                if np.min(np.linalg.norm(ends-seed,axis=1))>radius+1.:continue
                idx=[int(np.argmin(np.linalg.norm(nodes-q,axis=1))) for q in ends]
                if any(np.linalg.norm(nodes[j]-q)>.75 for j,q in zip(idx,ends)):continue
                d=np.minimum(distances[idx[0]]+s,distances[idx[1]]+s[-1]-s)
                # A large correction needs a longer approach, not a steeper
                # cosine hump. Bound the extra grade to 5 percent.
                if d.min()>radius:continue
                blend=.5*(1.+np.cos(np.pi*np.clip(d/radius,0.,1.)))
                # Add the local abutment correction to the existing road
                # profile. Replacing kilometres of a rolling road with the
                # abutment's tangent created broad motorway humps.
                nearest=int(np.argmin(np.linalg.norm(ends-seed,axis=1)))
                delta=top-p.z[0 if nearest==0 else -1] if np.linalg.norm(ends[nearest]-seed)<.75 else correction
                target=p.z+delta
                zz+=(target-zz)*blend
                upper_active |= d<radius
            for nodes,distances,floor,half,seed_line,seed_at in lower_cuts:
                ends=topology[[0,-1]]
                idx=[int(np.argmin(np.linalg.norm(nodes-q,axis=1))) for q in ends]
                if any(np.linalg.norm(nodes[j]-q)>.75 for j,q in zip(idx,ends)):continue
                d=np.minimum(distances[idx[0]]+s,distances[idx[1]]+s[-1]-s)
                # The crossing can be inside an edge, not at a graph node.
                dist,at,_=project(topology,seed_line)
                d=np.minimum(d,np.where(dist<.75,np.abs(at-seed_at),np.inf))
                run=np.maximum(0.,d-half-2.)
                target=floor+.05*(run-10.*(1.-np.exp(-run/10.)))
                zz=np.minimum(zz,target)
            if not np.array_equal(zz,p.z):
                from grading import Plan
                plans[i]=(fid,Plan(p.xy,zz,p.half))
            if sp.profile.mainline:
                from grading import Plan
                self.mainline_plans[(fid,tuple(p.xy[0]),tuple(p.xy[-1]))]=Plan(p.xy,zz,p.half)
            if upper_active.any():
                from grading import Plan
                keep=upper_active
                # Preserve separate intervals when both ends approach different decks.
                for run in np.split(np.flatnonzero(keep),np.flatnonzero(np.diff(np.flatnonzero(keep))>1)+1):
                    if len(run)>1:
                        key=(fid,tuple(np.round(p.xy[run[0]],2)),tuple(np.round(p.xy[run[-1]],2)))
                        self.upper_plans[key]=Plan(p.xy[run],zz[run],p.half)

    def excavate(self, xy, base, lift):
        """Keep terrain out of bridge slabs across their entire width, including verges.

        Zero depth exactly at abutments; the deck owns collision over the cavity.
        This applies identically to the physics block and visible near terrain.
        """
        out=np.asarray(base,float).copy()
        for line,z,half,_ in self.near(xy, 5.):
            lo=line.min(0)-half-2.;hi=line.max(0)+half+2.
            keep=((xy>=lo)&(xy<=hi)).all(1)
            ids=np.flatnonzero(keep)
            if not len(ids):continue
            dist,at,s=project(xy[ids],line)
            reach=np.minimum(at,s[-1]-at)
            depth=np.minimum(2.8,np.maximum(0.,reach)*.6)
            top=np.interp(at,s,z)
            inside=(dist<=half+1.)&(reach>.15)
            out[ids[inside]]=np.minimum(out[ids[inside]],top[inside]-depth[inside]+lift)
        for line,floor,half in self.paths(xy):
            u=(line[1]-line[0]);u/=max(np.linalg.norm(u),1e-9)
            v=(line[-1]-line[-2]);v/=max(np.linalg.norm(v),1e-9)
            extra=np.array([line[0]-30*u,line[-1]+30*v])
            outside=self.sample(extra)
            line=np.vstack([extra[0],line,extra[1]])
            floor=np.r_[outside[0],floor,outside[1]]
            lo=line.min(0)-half-3.;hi=line.max(0)+half+3.
            ids=np.flatnonzero(((xy>=lo)&(xy<=hi)).all(1))
            if not len(ids):continue
            dist,at,s=project(xy[ids],line)
            inside=dist<half+1.5
            weight=np.clip((half+1.5-dist)/1.5,0.,1.)
            target=np.interp(at,s,floor)+lift
            out[ids[inside]]-=np.maximum(0.,out[ids[inside]]-target[inside])*weight[inside]
        return out
