# Credits

BeamNG.Earth is built on open data, open-source software and the work of many people. This file
lists every data source, service, library, tool and reference the project uses or has used, with
its licence and the attribution it asks for. In game, the data credits overlay (a small text in a
screen corner, on by default; docs/DEVTOOLS.md) names the sources of what is around the player right
now, and the settings page shows it together with the full attribution line of the session.

Status: **in use** = used by the current main branch; **branch** = on a feature branch, not merged
yet; **planned** = in the roadmap, not used yet; **reference** = consulted for research or tuning
only, nothing redistributed. Licence notes marked *(verify)* must be re-checked before any release.

## Map data (downloaded at runtime by the companion server and cached on the player's disk)

UK road interpretation (2026-10-20): offline OpenStreetMap road attributes from Geofabrik UK extracts,
© OpenStreetMap contributors, ODbL 1.0 (<https://www.openstreetmap.org/copyright>). The prepared index records
the input extract SHA-256 hashes; Overture remains the geometry/topology source. UK rule selection uses ONS
Countries (December 2024) Boundaries UK BGC (20 m), under Open Government Licence v3.0:
UK boundaries: Contains OS data © Crown copyright and database right 2026. Contains National Statistics data © Crown copyright and database right 2026

Road attributes: © OpenStreetMap contributors

Regional lane/road attributes (2026-10-22): the supplemental Boston extract in
`.road-data/osm-extra.osm` and its derived SQLite index are © OpenStreetMap contributors,
ODbL 1.0 (<https://www.openstreetmap.org/copyright>), prepared through Overpass.
The source query, bounds and SHA-256 are in `.road-data/osm-extra.source.json`.

Source: <https://www.ons.gov.uk/methodology/geography/geographicalproducts/digitalboundaries>.
New UK paint textures and circular mph sign meshes/textures are original project assets.

| Data | Provider | Used for | Licence / terms | Attribution | Status |
|---|---|---|---|---|---|
| Natural Earth v5.1.2: 1:50m country and state / province boundary lines, 1:110m country label points, 1:10m populated places (scalerank <= 8) | Natural Earth (naturalearthdata.com; GeoJSON from github.com/nvkelso/natural-earth-vector) | the world map's Layers: borders and place names (shipped with the mod, `ui/.../maplayers.js`, ~0.7 MB) | public domain | "Made with Natural Earth" (not required) | in use |
| MD iMAP Six-Inch Imagery 2023-2025 (0.15 m), MapServer export | State of Maryland, MD iMAP / Department of Information Technology (DoIT) | the near ground imagery in Maryland (`--imagery` source "md6in", first in the chain there) | free distribution with acknowledgement (service metadata; re-verify before release) | "State of Maryland, MD iMAP / DoIT" | in use |
| National Bridge Inventory 2025 (all states, delimited; item 43B main span design, item 48 span) | U.S. Department of Transportation, Federal Highway Administration (FHWA) | which bridges are trusses (and arches, suspension, cable-stayed, movable) in the US: the 15,060 notable records, shipped with the server (`server/bridges_us.npz`, ~180 kB, built by `tools/build_bridge_db.py`; `server/bridgetypes.py`) | public domain (US federal) | "Bridge types: FHWA National Bridge Inventory" (not required) | branch (2026-10-18) |
| Wikidata: bridges with a structural type (instance of suspension / cable-stayed / arch / tied-arch / truss / cantilever / bascule / vertical-lift / swing / girder / beam bridge, or a subclass), their coordinates, longest span (P2787) and length (P2043) | Wikidata contributors (wikidata.org) | which bridges are arches, suspension, cable-stayed, trusses or movable worldwide, and their spans (7,956 bridges shipped with the server, `server/bridges_wd.npz`, ~75 kB, built by `tools/build_bridge_wikidata.py` with the Wikidata Query Service; `server/bridgetypes.py`) | CC0 1.0 | "Bridge types: Wikidata" (not required) | branch (2026-10-18) |
| NOAA NCEI DEM Global Mosaic (bathymetry; CUDEM ~3 m along the US coasts, coarser elsewhere), ImageServer export | NOAA National Centers for Environmental Information (NCEI) | sea floor depths (`--sea on`, `server/seacarve.py`) | US federal government data, public domain *(verify)* | "NOAA NCEI" | in use |
| USDA NAIP orthoimagery (0.3-0.6 m, 2024-25 flights), through USDA FPAC's NAIP ImageServer (exportImage) | U.S. Department of Agriculture (FPAC / FSA) | the near ground imagery in the lower 48 states where this service has it (`--imagery` source "naipusda", tried before "naip") | public domain (US federal) | "USDA NAIP" | in use |
| USDA NAIP orthoimagery (0.3-0.6 m), through the USGS NAIP ImageServer (exportImage) | U.S. Department of Agriculture (FSA) / U.S. Geological Survey | the near ground imagery in the lower 48 states (the block's photo, the nearest far tiles; `--imagery` source "naip") | public domain (US federal) | "USDA NAIP via USGS The National Map" | in use |
| USGS National Map ImageryOnly (NAIP-based orthoimagery) | U.S. Geological Survey | ground imagery in the US | public domain (US federal) | "Imagery: USGS The National Map" | in use |
| Sentinel-2 cloudless 2023 | EOX IT Services GmbH (s2maps.eu), contains modified Copernicus Sentinel data 2023 | ground imagery worldwide; the colour reference of `--colormatch s2` (in the session's attribution whenever it is on, and in the on-screen credits for the textures it corrected) | CC BY-NC-SA 4.0 (non-commercial) | "EOxCloudless https://cloudless.eox.at by EOX IT Services GmbH (Contains modified Copernicus Sentinel data 2023)" (EOX's June 2026 wording; imagery.py uses it) | in use |
| EOX Maps Terrain Light and Overlay (bright) tiles (`terrain-light_3857`, `overlay_bright_3857`, native to z14) | EOX IT Services GmbH (maps.eox.at); data © OpenStreetMap contributors, Natural Earth and others | the world map's Layers: the "Map" base map and the "Roads & labels" overlay (server/maptiles.py, fetched only for the tiles the map shows, cached) | EOX: "Just feel free to use them. We just ask for a link back", provided as is; data ODbL and others | "Map: Terrain Light [and Overlay] by EOX IT Services GmbH (maps.eox.at), data © OpenStreetMap contributors and others" (the map's credit line while either layer is shown) | in use (2026-10-16) |
| Sentinel-2 cloudless 2016 | EOX IT Services GmbH, contains modified Copernicus Sentinel data 2016 | imagery fallback; `--colormatch` reference fallback | CC BY 4.0 | as above, "...data 2016 & 2017)" | in use |
| Mapterhorn terrain tiles | Mapterhorn (aggregating many national and global elevation sources) | elevation | per source, see https://mapterhorn.com/attribution | "Elevation: Mapterhorn (see mapterhorn.com/attribution)" | in use |
| AWS Terrain Tiles (Terrarium) | Mapzen / Linux Foundation, hosted on AWS Open Data; sources incl. SRTM, GMTED2010, ETOPO1, USGS 3DEP/NED, and others | elevation fallback | per source, see https://github.com/tilezen/joerd/blob/master/docs/attribution.md | "AWS Terrain Tiles / Mapzen" + source list | in use |
| Open-Meteo forecast API | Open-Meteo.com (weather models from national weather services) | real weather, time zone | CC BY 4.0 data, free non-commercial API use | "Weather data by Open-Meteo.com" | in use |
| EGM2008 / EGM96 geopotential model | U.S. National Geospatial-Intelligence Agency (via GeographicLib data files) | real gravity incl. regional anomalies | public domain (NGA) *(verify the mirror's terms)* | "Gravity model: EGM2008, NGA" | in use |
| OpenStreetMap | OpenStreetMap contributors | roads, buildings, water, signs, places | ODbL 1.0 | "© OpenStreetMap contributors" | planned |
| Overture Maps GeoParquet, release 2026-09-23.1 (transportation, buildings, base: water, land use, infrastructure), via its STAC index | Overture Maps Foundation (from OpenStreetMap, TomTom, Microsoft, Google, Esri Community Maps, USGS 3DEP and others) | the map-data pipeline (`server/mapdata.py`): roads, buildings, water, land use, infrastructure; street widths measured between building footprints (`server/roadwidth.py`) | per theme (https://docs.overturemaps.org/attribution/, read 2026-10-11): transportation "ODbL. © OpenStreetMap contributors. Available under the Open Database License. Data from TomTom."; buildings "ODbL. © OpenStreetMap contributors. Available under the Open Database License. Esri Community Maps contributors. Available under CC BY 4.0. Global ML Building Footprints. Licensed by Microsoft under the Open Database License. Google Open Buildings. Available under CC BY 4.0. USGS 3D Elevation Program Digital Elevation Program. Qian Shi, et al. A First High-quality Vector Data of Buildings in East Asian Countries Based on a Comprehensive Large-scale Mapping Framework. Zenodo, 22 July 2023, doi:10.5281/zenodo.8174931. Available under CC BY 4.0. Work derived from BTN 2024 ign.es. Available under CC BY 4.0"; base "ODbL. © OpenStreetMap contributors. Available under the Open Database License. Data from the Daylight Map Distribution. ESA WorldCover. © ESA WorldCover project 2020 / Contains modified Copernicus Sentinel data (2020) processed by ESA WorldCover consortium. Available under CC BY 4.0 DEED. Data products from ETOPO1. Available under Open Data Commons Public Domain Dedication and License. Data from GLOBathy. Available under CC0 1.0 (assumed)." (`overture.THEME_LICENCES`, whole). Each cell's provenance lists the source datasets and licences of its features; the CC BY ones (Esri Community Maps, Google Open Buildings, the East Asia buildings, BTN) need their credit in the overlay where they are shown (`CellData.provenance` names them). The local cache is a derivative database kept on the player's disk, not redistributed | "© OpenStreetMap contributors, Overture Maps Foundation" (Overture's own wording) | branch (feature/mapdata) |
| ESA WorldCover 10 m 2021 v200 (`esa-worldcover` S3 COGs) | European Space Agency / WorldCover consortium (VITO) | land cover per cell (`server/mapdata.py`); planned: surface types, ground materials | CC BY 4.0 (https://creativecommons.org/licenses/by/4.0/; the files' own metadata: "CC-BY 4.0") | "© ESA WorldCover project 2021 / Contains modified Copernicus Sentinel data (2021) processed by ESA WorldCover consortium" (the files' copyright line) | branch (feature/mapdata) |
| Meta / WRI High Resolution Canopy Height Maps v2 (CHMv2, 1.19 m, `dataforgood-fb-data` S3 COGs) | Meta and World Resources Institute | canopy height per cell (`server/mapdata.py`); planned: tree placement | CC BY 4.0 (https://registry.opendata.aws/dataforgood-fb-forests/) | "Canopy height: Meta & WRI" in the overlay; full: "Canopy height: Meta and World Resources Institute (WRI), High Resolution Canopy Height Maps" (the registry's citation: "Meta and World Resources Institude (WRI) - 2024. High Resolution Canopy Height Maps (CHM). Source imagery for CHM © 2016 Maxar.", sic, written for v1) | branch (feature/mapdata) |
| OurAirports (airports.csv, runways.csv; the nightly dump at https://davidmegginson.github.io/ourairports-data/, read 2026-10-11) | OurAirports (David Megginson and contributors) | airports and runways: positions, lengths, widths, surfaces, elevations, headings, displaced thresholds, helipads (`server/airports.py`; graded runways and markings) | Public domain. The terms of use at https://ourairports.com/data/, verbatim: "All data is released to the Public Domain, and comes with no guarantee of accuracy or fitness for use." (read 2026-10-11 from the Internet Archive capture of 2026-09-29: ourairports.com's TLS certificate had expired that day). The download repository github.com/davidmegginson/ourairports-data is under The Unlicense. Credit is welcome, not required | "Airports: OurAirports (public domain)" (`airports.CREDIT`) | branch (feature/airports) |
| NLCD | U.S. Geological Survey / MRLC | US land cover detail | public domain | "NLCD, USGS/MRLC" | planned |
| GEBCO grid | GEBCO Compilation Group | ocean and lake depths | public domain with attribution | "GEBCO Compilation Group (year) GEBCO Grid" | planned |
| NOAA coastal DEMs / Great Lakes bathymetry | NOAA NCEI | coastal and lake depths | public domain | "NOAA NCEI" | planned |
| Connecticut orthophotos (tile cache, cteco.uconn.edu) | the publishing agency | the near and middle-distance ground imagery there (`--imagery` source "ct2023", ahead of NAIP / USGS / Sentinel-2) | per the service (open or free reuse; docs/research/2026-10-10-us-state-imagery.md and imagery-sources-world.md; re-verify before release) | "CT ECO 2023 orthoimagery (CC0)" | in use |
| Massachusetts orthophotos (tile cache, tiles.arcgis.com) | the publishing agency | the near and middle-distance ground imagery there (`--imagery` source "ma2025", ahead of NAIP / USGS / Sentinel-2) | per the service (open or free reuse; docs/research/2026-10-10-us-state-imagery.md and imagery-sources-world.md; re-verify before release) | "MassGIS 2025 aerial imagery" | in use |
| District of Columbia orthophotos (WMS / ArcGIS export, imagery.dcgis.dc.gov) | the publishing agency | the near and middle-distance ground imagery there (`--imagery` source "dc2025", ahead of NAIP / USGS / Sentinel-2) | per the service (open or free reuse; docs/research/2026-10-10-us-state-imagery.md and imagery-sources-world.md; re-verify before release) | "DC OCTO 2025 orthophoto (CC BY 4.0)" | in use |
| Indiana orthophotos (tile cache, di-ingov.img.arcgis.com) | the publishing agency | the near and middle-distance ground imagery there (`--imagery` source "indiana", ahead of NAIP / USGS / Sentinel-2) | per the service (open or free reuse; docs/research/2026-10-10-us-state-imagery.md and imagery-sources-world.md; re-verify before release) | "Indiana IGIO orthoimagery (CC0)" | in use |
| Ohio orthophotos (tile cache, maps.ohio.gov) | the publishing agency | the near and middle-distance ground imagery there (`--imagery` source "ohio", ahead of NAIP / USGS / Sentinel-2) | per the service (open or free reuse; docs/research/2026-10-10-us-state-imagery.md and imagery-sources-world.md; re-verify before release) | "OGRIP OSIP orthoimagery (public domain)" | in use |
| North Carolina orthophotos (tile cache, services.nconemap.gov) | the publishing agency | the near and middle-distance ground imagery there (`--imagery` source "ncarolina", ahead of NAIP / USGS / Sentinel-2) | per the service (open or free reuse; docs/research/2026-10-10-us-state-imagery.md and imagery-sources-world.md; re-verify before release) | "NC OneMap orthoimagery (NC CGIA, NC 911 Board)" | in use |
| Pennsylvania orthophotos (tile cache, imagery.pasda.psu.edu) | the publishing agency | the near and middle-distance ground imagery there (`--imagery` source "penn", ahead of NAIP / USGS / Sentinel-2) | per the service (open or free reuse; docs/research/2026-10-10-us-state-imagery.md and imagery-sources-world.md; re-verify before release) | "PEMA orthoimagery via PASDA" | in use |
| Virginia orthophotos (tile cache, vginmaps.vdem.virginia.gov) | the publishing agency | the near and middle-distance ground imagery there (`--imagery` source "virginia", ahead of NAIP / USGS / Sentinel-2) | per the service (open or free reuse; docs/research/2026-10-10-us-state-imagery.md and imagery-sources-world.md; re-verify before release) | "VGIN VBMP imagery" | in use |
| New York State orthophotos (WMS / ArcGIS export, orthos.its.ny.gov) | the publishing agency | the near and middle-distance ground imagery there (`--imagery` source "newyork", ahead of NAIP / USGS / Sentinel-2) | per the service (open or free reuse; docs/research/2026-10-10-us-state-imagery.md and imagery-sources-world.md; re-verify before release) | "NYS ITS GIS Program Office orthoimagery" | in use |
| New Jersey orthophotos (tile cache, maps.nj.gov) | the publishing agency | the near and middle-distance ground imagery there (`--imagery` source "newjersey", ahead of NAIP / USGS / Sentinel-2) | per the service (open or free reuse; docs/research/2026-10-10-us-state-imagery.md and imagery-sources-world.md; re-verify before release) | "NJ OIT Office of GIS 2020 orthoimagery" | in use |
| Delaware orthophotos (tile cache, imagery.firstmap.delaware.gov) | the publishing agency | the near and middle-distance ground imagery there (`--imagery` source "delaware", ahead of NAIP / USGS / Sentinel-2) | per the service (open or free reuse; docs/research/2026-10-10-us-state-imagery.md and imagery-sources-world.md; re-verify before release) | "Delaware FirstMap 2024 imagery" | in use |
| Vermont orthophotos (tile cache, maps.vcgi.vermont.gov) | the publishing agency | the near and middle-distance ground imagery there (`--imagery` source "vermont", ahead of NAIP / USGS / Sentinel-2) | per the service (open or free reuse; docs/research/2026-10-10-us-state-imagery.md and imagery-sources-world.md; re-verify before release) | "VCGI orthoimagery" | in use |
| Switzerland orthophotos (tile cache, wmts.geo.admin.ch) | the publishing agency | the near and middle-distance ground imagery there (`--imagery` source "swiss", ahead of NAIP / USGS / Sentinel-2) | per the service (open or free reuse; docs/research/2026-10-10-us-state-imagery.md and imagery-sources-world.md; re-verify before release) | "(c) swisstopo SWISSIMAGE" | in use |
| France orthophotos (tile cache, data.geopf.fr) | the publishing agency | the near and middle-distance ground imagery there (`--imagery` source "france", ahead of NAIP / USGS / Sentinel-2) | per the service (open or free reuse; docs/research/2026-10-10-us-state-imagery.md and imagery-sources-world.md; re-verify before release) | "IGN BD ORTHO (Licence Ouverte 2.0)" | in use |
| Spain orthophotos (tile cache, tms-pnoa-ma.idee.es) | the publishing agency | the near and middle-distance ground imagery there (`--imagery` source "spain", ahead of NAIP / USGS / Sentinel-2) | per the service (open or free reuse; docs/research/2026-10-10-us-state-imagery.md and imagery-sources-world.md; re-verify before release) | "PNOA (c) IGN Espana (CC BY 4.0)" | in use |
| Netherlands orthophotos (tile cache, service.pdok.nl) | the publishing agency | the near and middle-distance ground imagery there (`--imagery` source "netherlands", ahead of NAIP / USGS / Sentinel-2) | per the service (open or free reuse; docs/research/2026-10-10-us-state-imagery.md and imagery-sources-world.md; re-verify before release) | "Beeldmateriaal.nl / PDOK (CC BY 4.0)" | in use |
| Luxembourg orthophotos (tile cache, wmts1.geoportail.lu) | the publishing agency | the near and middle-distance ground imagery there (`--imagery` source "luxembourg", ahead of NAIP / USGS / Sentinel-2) | per the service (open or free reuse; docs/research/2026-10-10-us-state-imagery.md and imagery-sources-world.md; re-verify before release) | "geoportail.lu orthophoto (CC0)" | in use |
| Austria orthophotos (tile cache, maps.wien.gv.at) | the publishing agency | the near and middle-distance ground imagery there (`--imagery` source "austria", ahead of NAIP / USGS / Sentinel-2) | per the service (open or free reuse; docs/research/2026-10-10-us-state-imagery.md and imagery-sources-world.md; re-verify before release) | "Datenquelle: basemap.at (CC BY 4.0)" | in use |
| Czechia orthophotos (tile cache, ags.cuzk.gov.cz) | the publishing agency | the near and middle-distance ground imagery there (`--imagery` source "czechia", ahead of NAIP / USGS / Sentinel-2) | per the service (open or free reuse; docs/research/2026-10-10-us-state-imagery.md and imagery-sources-world.md; re-verify before release) | "(c) CUZK ortofoto (CC BY 4.0)" | in use |
| Estonia orthophotos (tile cache, tiles.maaamet.ee) | the publishing agency | the near and middle-distance ground imagery there (`--imagery` source "estonia", ahead of NAIP / USGS / Sentinel-2) | per the service (open or free reuse; docs/research/2026-10-10-us-state-imagery.md and imagery-sources-world.md; re-verify before release) | "Ortofoto: Maa-amet" | in use |
| Flanders (Belgium) orthophotos (WMS / ArcGIS export, geo.api.vlaanderen.be) | the publishing agency | the near and middle-distance ground imagery there (`--imagery` source "flanders", ahead of NAIP / USGS / Sentinel-2) | per the service (open or free reuse; docs/research/2026-10-10-us-state-imagery.md and imagery-sources-world.md; re-verify before release) | "Digitaal Vlaanderen orthophoto" | in use |
| Bavaria (Germany) orthophotos (WMS / ArcGIS export, geoservices.bayern.de) | the publishing agency | the near and middle-distance ground imagery there (`--imagery` source "de_bayern", ahead of NAIP / USGS / Sentinel-2) | per the service (open or free reuse; docs/research/2026-10-10-us-state-imagery.md and imagery-sources-world.md; re-verify before release) | "Bayerische Vermessungsverwaltung DOP20 (CC BY 4.0)" | in use |
| North Rhine-Westphalia (Germany) orthophotos (WMS / ArcGIS export, www.wms.nrw.de) | the publishing agency | the near and middle-distance ground imagery there (`--imagery` source "de_nrw", ahead of NAIP / USGS / Sentinel-2) | per the service (open or free reuse; docs/research/2026-10-10-us-state-imagery.md and imagery-sources-world.md; re-verify before release) | "Geobasis NRW DOP (dl-de/zero-2-0)" | in use |
| Baden-Wuerttemberg (Germany) orthophotos (WMS / ArcGIS export, owsproxy.lgl-bw.de) | the publishing agency | the near and middle-distance ground imagery there (`--imagery` source "de_bw", ahead of NAIP / USGS / Sentinel-2) | per the service (open or free reuse; docs/research/2026-10-10-us-state-imagery.md and imagery-sources-world.md; re-verify before release) | "LGL Baden-Wuerttemberg DOP20 (dl-de/by-2-0)" | in use |
| Lower Saxony (Germany) orthophotos (WMS / ArcGIS export, opendata.lgln.niedersachsen.de) | the publishing agency | the near and middle-distance ground imagery there (`--imagery` source "de_nds", ahead of NAIP / USGS / Sentinel-2) | per the service (open or free reuse; docs/research/2026-10-10-us-state-imagery.md and imagery-sources-world.md; re-verify before release) | "LGLN Niedersachsen DOP20 (dl-de/by-2-0)" | in use |
| Berlin (Germany) orthophotos (WMS / ArcGIS export, gdi.berlin.de) | the publishing agency | the near and middle-distance ground imagery there (`--imagery` source "de_berlin", ahead of NAIP / USGS / Sentinel-2) | per the service (open or free reuse; docs/research/2026-10-10-us-state-imagery.md and imagery-sources-world.md; re-verify before release) | "Geoportal Berlin TrueDOP 2024 (dl-de/zero-2-0)" | in use |
| Hesse (Germany) orthophotos (WMS / ArcGIS export, www.gds-srv.hessen.de) | the publishing agency | the near and middle-distance ground imagery there (`--imagery` source "de_hessen", ahead of NAIP / USGS / Sentinel-2) | per the service (open or free reuse; docs/research/2026-10-10-us-state-imagery.md and imagery-sources-world.md; re-verify before release) | "HVBG Hessen DOP20" | in use |
| Japan orthophotos (tile cache, cyberjapandata.gsi.go.jp) | the publishing agency | the near and middle-distance ground imagery there (`--imagery` source "japan", ahead of NAIP / USGS / Sentinel-2) | per the service (open or free reuse; docs/research/2026-10-10-us-state-imagery.md and imagery-sources-world.md; re-verify before release) | "GSI Japan (Geospatial Information Authority of Japan) seamless photo" | in use |
| New South Wales (Australia) orthophotos (tile cache, maps.six.nsw.gov.au) | the publishing agency | the near and middle-distance ground imagery there (`--imagery` source "au_nsw", ahead of NAIP / USGS / Sentinel-2) | per the service (open or free reuse; docs/research/2026-10-10-us-state-imagery.md and imagery-sources-world.md; re-verify before release) | "(c) Spatial Services NSW (CC BY 4.0)" | in use |
| Tasmania (Australia) orthophotos (tile cache, services.thelist.tas.gov.au) | the publishing agency | the near and middle-distance ground imagery there (`--imagery` source "au_tas", ahead of NAIP / USGS / Sentinel-2) | per the service (open or free reuse; docs/research/2026-10-10-us-state-imagery.md and imagery-sources-world.md; re-verify before release) | "(c) State of Tasmania theLIST" | in use |
| Ontario (Canada) orthophotos (WMS / ArcGIS export, ws.geoservices.lrc.gov.on.ca) | the publishing agency | the near and middle-distance ground imagery there (`--imagery` source "ontario", ahead of NAIP / USGS / Sentinel-2) | per the service (open or free reuse; docs/research/2026-10-10-us-state-imagery.md and imagery-sources-world.md; re-verify before release) | "Ontario GEO imagery (Open Government Licence - Ontario)" | in use |
| OSRM routing (FOSSGIS / project-osrm demo) | FOSSGIS e.V. / Project OSRM, on OpenStreetMap data | long-distance GPS | service terms (light, non-commercial use); data ODbL | "Routing: OSRM, © OpenStreetMap contributors" | planned |
| OSRM routing (routing.openstreetmap.de) | FOSSGIS e.V. (hosting), OSRM project; data by OpenStreetMap contributors | the GPS's whole-route planning (server/routing.py; the start and the destination are sent to it, one request per route / re-route) | FOSSGIS fair use (valid User-Agent, no bulk); OSRM BSD-2; data ODbL | "Routing: OSRM by FOSSGIS, © OpenStreetMap contributors" | in use (2026-10-14) |
| Photon geocoding (photon.komoot.io) | komoot (Photon); data by OpenStreetMap contributors | the world map's address / place search (server/geocode.py; the typed text and the player's position are sent to komoot) | Photon fair-use terms; data ODbL | "Search: Photon by komoot, © OpenStreetMap contributors" (shown under the search results) | in use (2026-10-14); Nominatim not used (its policy forbids autocomplete) |
| GitHub raw content (raw.githubusercontent.com) | GitHub (Microsoft) | the update check (server/updates.py): the project's VERSION file on main, a few times a day at most; nothing about the player is sent beyond the request itself | GitHub terms of service | none needed | in use (2026-10-15) |
| 3D BAG (LoD 2.2 buildings, Netherlands) | 3DBAG (TU Delft 3D geoinformation group) | building shapes and roofs | CC BY 4.0 | "3DBAG by tudelft3d and 3DGI" | planned |
| German state LoD2 building models (NRW, Bavaria, Berlin, ...) | the state survey offices | building shapes and roofs | DL-DE Zero / DL-DE BY 2.0 / CC BY 4.0 per state *(verify Bavaria: CC BY vs BY-ND)* | per state | planned |
| swissBUILDINGS3D | swisstopo | building shapes and roofs | open (swisstopo OGD terms) | "© swisstopo" | planned |
| PLATEAU 3D city models | Japan MLIT | building shapes and roofs | PLATEAU terms (CC BY 4.0 compatible) | "PLATEAU (MLIT)" | planned |
| DC Buildings 3D 2024 | DC Office of the CTO | benchmark near Baltimore | CC BY 4.0 | "DC OCTO" | planned (benchmark) |
| USGS 3DEP lidar point clouds | U.S. Geological Survey | building heights/roofs and canopy in the US | public domain | "USGS 3DEP" | planned |
| LiDAR HD | IGN France | buildings, canopy heights | Etalab Open Licence 2.0 | "IGN - LiDAR HD" | planned |
| Mapillary street-level imagery | Mapillary (Meta) | tuning the city generator against real photos | CC BY-SA 4.0, free API token | "Street-level imagery: Mapillary" | planned (reference) |

## Software and libraries

| Software | Used for | Licence | Status |
|---|---|---|---|
| BeamNG.drive (BeamNG GmbH) | the game; its Lua API, engine, built-in MCP server, and stock assets referenced at runtime (never redistributed) | proprietary game; this is an unofficial fan mod | in use |
| Python 3 | companion server and tools | PSF License | in use |
| NumPy | terrain, mesh and imagery processing | BSD-3-Clause | in use |
| Pillow | image decoding and encoding | MIT-CMU (HPND) | in use |
| LuaJIT | offline tests of the mod's Lua | MIT | in use (tests) |
| GeographicLib (data files) | gravity model data | MIT (library) / NGA data public domain | in use |
| Leaflet | world map page | BSD-2-Clause | not used: the in-game world map (`EarthMap.vue`, `mapmath.js`) is our own code. Its tiles come from the imagery chain above (USGS, EOX Sentinel-2 cloudless 2023 / 2016) through `server/maptiles.py` and show that same attribution, plus the EOX Terrain Light / Overlay layers above |
| DuckDB | reading Overture GeoParquet (`server/overture.py`; no extensions) | MIT | branch (feature/mapdata) |
| fsspec | the filesystem interface DuckDB reads the remote files through (`server/rangeread.py`) | BSD-3-Clause | branch (feature/mapdata) |
| Git, GitHub, GitHub CLI | version control and hosting | GPL-2.0 (git) / MIT (gh) | in use |

## Tools

- **Claude Code** (Anthropic): the AI coding assistant that designed, wrote and tested most of the code
  and research in this repository together with the project owner.
- BeamNG's built-in MCP server (Options > Advanced) for in-game probes and automated test drives.

## References and inspiration (consulted, nothing redistributed)

- Mapillary street-level photos (© Mapillary contributors, CC BY-SA 4.0), through the Mapillary API with
  the user's own token, as references for street-level comparison (tools/streetview.py; kept local, not
  redistributed).
- USGS NAIP orthoimagery (U.S. Department of Agriculture / USGS, public domain), through the USGS
  ImageServer, as bird's-eye references for road and intersection geometry (tools/ortho_naip.py,
  tools/ortho_overlay.py; kept local).

- BeamNG's official levels (West Coast USA, Johnson Valley, Utah, Italy, East Coast USA, Jungle Rock
  Island, Hirochi Raceway) as look references and stock-asset sources per biome (docs/ROADMAP.md). The
  ground cover uses Hirochi Raceway's and West Coast USA's grass and scrub definitions and materials,
  read from the player's own game install at runtime (nothing copied into the mod), and so are the road
  materials (West Coast USA's asphalt strip, sidewalks, gutters and lines; Johnson Valley's dirt road
  tracks; Italy's cobblestone; West Coast USA's curbs and sidewalk1 on our sidewalk meshes; Driver
  Training's metal grid drain).
- Torque3D (open-source engine BeamNG derives from) source code and docs, for engine behaviour.
- Sebastien Hillaire, "A Scalable and Production Ready Sky and Atmosphere Rendering Technique" (2020),
  the model behind the game's 0.39 sky (for the horizon matching work).
- Open-source projects studied for generation methods: OSM2World, Blosm (blender-osm), Streets GL,
  vts-geospatial, OSRM, Valhalla.
- Popular off-road and rock-crawling trails and their public photos/videos as tuning references for
  terrain and surface generation (e.g. Moab's trails, the Rubicon Trail, Johnson Valley's Hammers);
  see docs/ROADMAP.md. Only used to judge the look; no imagery from them is shipped.
- NAIP flight specifications (sun elevation rules) for the de-shadowing sun fit.
- BeamNG maps built from real lidar, as drive-and-compare references only: "Pikes Peak - LIDAR Edition"
  and "Road Atlanta - LIDAR Edition" (Ewanc), "Mount Coot-tha" (B25Mitch), "Sangerhausen"
  (ElTacoLoco), "Roane County" (bob.blunderton).
- "Polish Roads" by mcct (BeamNG resource 5846, summer and winter versions) and MuYe's video "They
  Added Seasons To BeamNG": visual reference for winter roads, snow, plowing and road surface quality
  by road use. Its assets are not used (the author does not allow reuse).
- The project owner's own knowledge of Fells Point, Baltimore, and their in-game reports.
- Photo benchmark (docs/PLACES.md, docs/benchmarks.json `whitney_photo_south`): "A346, from summit
  of Mount Whitney, California, USA, 2011" by Brian W. Schaller, Wikimedia Commons, CC BY-NC-SA 4.0
  / Free Art License 1.3. Linked, never copied into the repository; only our own renders of the same
  view are kept.
- ICAO Annex 14 Volume I (Aerodrome Design and Operations), FAA Advisory Circulars 150/5300-13B (Airport
  Design) and 150/5340-1M (Standards for Airport Markings): the runway grading limits and marking dimensions of
  `server/runwaygeom.py` and `server/runwaymarks.py` (numbers only; nothing copied).
- BeamNG.drive's `art/groundmodels.json` (in `gameengine.zip`): the ground model names runway surfaces map to
  (read, not redistributed).
- Z. Wang, A. C. Bovik, H. R. Sheikh, E. P. Simoncelli, "Image quality assessment: from error
  visibility to structural similarity", IEEE Trans. Image Processing 13(4), 2004: the SSIM measure
  `tools/benchmark.py compare` uses (own NumPy implementation).

## User mods mentioned in the docs (not part of BeamNG.Earth)

BWM_Weather, TAA Standalone, PerformanceTweaker, Enhanced Vehicle FX, Realistic Driver Camera,
Dynamic Damage Particles, Dynamic Scratches, SparkMod: other authors' mods the project owner uses;
BeamNG.Earth only coexists with them (e.g. the weather module backs off when BWM_Weather drives the
weather). The pause-menu integration follows the pattern of the TAA Standalone mod.
